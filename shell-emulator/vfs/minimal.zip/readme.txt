Minimal VFS
